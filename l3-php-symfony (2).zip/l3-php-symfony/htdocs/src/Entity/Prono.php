<?php

namespace App\Entity;

use App\Repository\PronoRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PronoRepository::class)
 */
class Prono
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="string")
     */
    private $id;

    /**
     * @ORM\Column(type="string")
     */
    private $user;

    /**
     * @ORM\Column(type="string")
     */
    private $score_domicile;

    /**
     * @ORM\Column(type="string")
     */
    private $score_exterieur;

    /**
     * @ORM\Column(type="string")
     */
    private $key_match;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getUser()
    {
        return $this->user;
    }

    public function setUser($user): self
    {
        $this->user = $user;

        return $this;
    }

    public function getScoreDomicile()
    {
        return $this->score_domicile;
    }

    public function setScoreDomicile($score_domicile): self
    {
        $this->score_domicile = $score_domicile;

        return $this;
    }

    public function getScoreExterieur()
    {
        return $this->score_exterieur;
    }

    public function setScoreExterieur($score_exterieur): self
    {
        $this->score_exterieur = $score_exterieur;

        return $this;
    }

    public function getKeyMatch()
    {
        return $this->key_match;
    }

    public function setKeyMatch($key_match): self
    {
        $this->key_match = $key_match;

        return $this;
    }
}
