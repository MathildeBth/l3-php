<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ContactController extends AbstractController
{
    public function contact(Request $request)
    {
        // Create the form according to the FormType created previously.
        // And give the proper parameters
        $form = $this->createForm('App\Form\ContactFormType',null,array(
            // To set the action use $this->generateUrl('route_identifier')
            'action' => $this->generateUrl('contact'),
            'method' => 'POST'
        ));

        if ($request->isMethod('POST')) {
            // Refill the fields in case the form is not valid.
            $form->handleRequest($request);

            if($form->isValid()){
                // Send mail
                if($this->sendEmail($form->getData())){

                    // Everything OK, redirect to wherever you want ! :

                    return $this->redirectToRoute('redirect_to_somewhere_now');
                }else{
                    // An error ocurred, handle
                    var_dump("Errooooor :(");
                }
            }
        }

        return $this->render('contact/contact.html.twig', array(
            'form' => $form->createView()
        ));
    }

    private function sendEmail($data){
        $myappContactMail = 'berthe.mathilde@hotmail.com';
        //$myappContactPassword = 'yourmailpassword';

        // In this case we'll use the ZOHO mail services.
        // If your service is another, then read the following article to know which smpt code to use and which port
        // http://ourcodeworld.com/articles/read/14/swiftmailer-send-mails-from-php-easily-and-effortlessly
        $transport = (new Swift_SmtpTransport('smtp.hotmail.com', 25))
            ->setUsername('Mathilde')
        ;

        $mailer = new Swift_Mailer($myappContactMail);

        $message = (new Swift_Message('Wonderful Subject'))
            ->setFrom(['berthe.mathilde@hotmail.com' => 'Mathilde'])
            ->setTo(['berthe.mathilde@hotmail.com', 'berthe.mathilde@hotmail.com' => 'A name'])
            ->setBody('Here is the message itself')
        ;

        $result = $mailer->send($message);
        return $result;
    }
}