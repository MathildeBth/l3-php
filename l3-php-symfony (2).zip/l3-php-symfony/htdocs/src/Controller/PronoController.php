<?php

namespace App\Controller;

use Doctrine\ORM\Mapping\Entity;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use App\Entity\Prono;
use App\Entity\User;

class PronoController extends AbstractController
{
    public function prono(): Response
    {
        $match = $_POST['key'];
        $pronoD = $_POST['pronosticd'];
        $pronoE = $_POST['pronostice'];

        $userID = $this->getUser();
        $userID = $userID->getID();

        $entityManager = $this->getDoctrine()->getManager();

        $prono = new Prono();
        $prono->setKeyMatch($match);
        $prono->setScoreDomicile($pronoD);
        $prono->setScoreExterieur($pronoE);
        $prono->setUser($userID);

        $entityManager->persist($prono);
        $entityManager->flush();

        return $this->render('home/home.html.twig');
    }
}