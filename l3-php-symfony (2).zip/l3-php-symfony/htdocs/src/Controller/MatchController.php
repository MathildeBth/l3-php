<?php


namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class MatchController extends AbstractController
{
    private $client;

    public function match(): Response
    {
        $match = $this->getMatch();
        return $this->render('matchs/index.html.twig', ['matchs' => $match]);
    }

    public function __construct(HttpClientInterface $client)
    {
        $this->client = $client;
    }

    public function getMatch(): array
    {
        $response = $this->client->request(
            'GET',
            'http://mathys-pomier.fr:4000/euro'
        );
        $statusCode = $response->getStatusCode();
        $contentType = $response->getHeaders()['content-type'][0];
        $content = $response->getContent();
        $content = $response->toArray();

        return $content;
    }
}