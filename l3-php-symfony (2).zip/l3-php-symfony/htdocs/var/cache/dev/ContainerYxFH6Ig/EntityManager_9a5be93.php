<?php

namespace ContainerYxFH6Ig;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder4de19 = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer011c2 = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesebfec = [
        
    ];

    public function getConnection()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getConnection', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getMetadataFactory', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getExpressionBuilder', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'beginTransaction', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getCache', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getCache();
    }

    public function transactional($func)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'transactional', array('func' => $func), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->transactional($func);
    }

    public function commit()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'commit', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->commit();
    }

    public function rollback()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'rollback', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getClassMetadata', array('className' => $className), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'createQuery', array('dql' => $dql), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'createNamedQuery', array('name' => $name), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'createQueryBuilder', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'flush', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'clear', array('entityName' => $entityName), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->clear($entityName);
    }

    public function close()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'close', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->close();
    }

    public function persist($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'persist', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'remove', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'refresh', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'detach', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'merge', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getRepository', array('entityName' => $entityName), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'contains', array('entity' => $entity), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getEventManager', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getConfiguration', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'isOpen', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getUnitOfWork', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getProxyFactory', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'initializeObject', array('obj' => $obj), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'getFilters', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'isFiltersStateClean', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'hasFilters', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return $this->valueHolder4de19->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer011c2 = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder4de19) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder4de19 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder4de19->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__get', ['name' => $name], $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        if (isset(self::$publicPropertiesebfec[$name])) {
            return $this->valueHolder4de19->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4de19;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4de19;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4de19;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder4de19;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__isset', array('name' => $name), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4de19;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder4de19;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__unset', array('name' => $name), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4de19;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder4de19;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__clone', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        $this->valueHolder4de19 = clone $this->valueHolder4de19;
    }

    public function __sleep()
    {
        $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, '__sleep', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;

        return array('valueHolder4de19');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer011c2 = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer011c2;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer011c2 && ($this->initializer011c2->__invoke($valueHolder4de19, $this, 'initializeProxy', array(), $this->initializer011c2) || 1) && $this->valueHolder4de19 = $valueHolder4de19;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder4de19;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder4de19;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
