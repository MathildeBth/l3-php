<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210709124921 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE prono (id INT AUTO_INCREMENT NOT NULL, user VARCHAR(255) NOT NULL, score_domicile VARCHAR(255) NOT NULL, score_exterieur VARCHAR(255) NOT NULL, key_match VARCHAR(255) NOT NULL, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB');
        $this->addSql('DROP TABLE pronostic');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE pronostic (id INT AUTO_INCREMENT NOT NULL, user VARCHAR(180) CHARACTER SET utf8 NOT NULL COLLATE `utf8_general_ci`, score_domicile VARCHAR(50) CHARACTER SET utf8 NOT NULL COLLATE `utf8_bin`, score_exterieur VARCHAR(50) CHARACTER SET utf8 NOT NULL COLLATE `utf8_bin`, key_match VARCHAR(10) CHARACTER SET utf8 NOT NULL COLLATE `utf8_bin`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8 COLLATE `utf8_unicode_ci` ENGINE = MyISAM COMMENT = \'\' ');
        $this->addSql('DROP TABLE prono');
    }
}
